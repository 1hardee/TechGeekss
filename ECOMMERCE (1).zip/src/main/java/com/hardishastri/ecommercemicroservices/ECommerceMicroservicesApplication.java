package com.hardishastri.ecommercemicroservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ECommerceMicroservicesApplication {

    public static void main(String[] args) {
        SpringApplication.run(ECommerceMicroservicesApplication.class, args);
    }

}
