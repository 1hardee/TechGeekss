package com.hardishastri.ecommercemicroservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ECommerceMicroservicesApplicationTests {

    @Test
    void contextLoads() {
    }

}
