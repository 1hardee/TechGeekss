package com.hardishastri.imageservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImageServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
