package com.hardishastri.produtservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProdutServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProdutServiceApplication.class, args);
    }

}
